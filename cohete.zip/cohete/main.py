import argparse
from utils.projectile_functions import dSdt
from utils.projectile_functions import resolverEDO
import matplotlib.pyplot as plt

def main(resAire,velInicial,tiempoVuelo,angulos):

    #resAire = B 
    #velInicial = V
    #tiempoVuelo = t
    #angulos = angulos 

    # Resolver la trayectoria para cada ángulo y graficarla
    for angulo in angulos:
        # Se resuelve la EDO para el ángulo actual
        solucion = resolverEDO(resAire, velInicial, tiempoVuelo, angulo)
        # Se grafica x vs y de la trayectoria obtenida
        plt.plot(
            solucion.y[0],   # posición en x
            solucion.y[2],   # posición en y
            label=fr'$\theta_0={angulo}^\circ$'
        )

    plt.ylim(bottom=0)   # limitar eje y desde 0
    plt.xlabel("$x/g$", fontsize=14)
    plt.ylabel("$y/g$", fontsize=14)
    plt.title("Trayectoria del cohete")
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == '__main__':
    # Se crea el parser de argumentos de línea de comandos
    parser = argparse.ArgumentParser(description='Lanzamiento de un cohete')

    # Argumento para la resistencia del aire
    parser.add_argument('-B', '--resAire',type = float, default = 0.1, help = "Se declara la variable para la resistencia del aire, ej. 0.1")

    # Argumento para la velocidad inicial
    parser.add_argument('-V','--velInicial',type=float, default = 1, help = "Se declara la variable para la velocidad inicial del lanzamiento")

    # Argumento para el tiempo de vuelo
    parser.add_argument('-t','--tiempoVuelo' ,type=float,default = 2, help = "tiempo de vuelo")

    # Argumento para los ángulos donde acepta múltiples valores
    parser.add_argument('-a', '--angulos',type=float,nargs='+', default = [40,45,50,60], help = "Se declaran n angulos de lanzamiento para el cohete")
    
    args = parser.parse_args()
    main(args.resAire, args.velInicial, args.tiempoVuelo, args.angulos)
